import sys
import subprocess
import time

_hack_cmd_= './hack.out'

def try_pin(values):
	"""This function returns True if you selected the right pin. Otherwise it returns False"""
	if len(values) != 4:
		print "invalid number of values.  must have 4, you provided " + str(len(values))
		return False

	cmd = [_hack_cmd_]

	valueString = map(lambda x: str(x), values)
	hackInput = ' '.join(valueString)
	hackInput += '\n'
	proc = subprocess.Popen(
		cmd, 
		stdin=subprocess.PIPE)
	try:
		proc.communicate(hackInput)
	except IOError:
		time.sleep(1)
		proc.communicate(hackInput)
	
	return (proc.returncode == 1)
	




