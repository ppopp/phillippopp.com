import sys
import subprocess
import time

_hack_cmd_= './hack02.out'

def guess(num):
	"""This function returns -1 if your guess is less than the secret number, 0 if it's the right guess, or 1 if your gess is greater than the secret number"""

	cmd = [_hack_cmd_]
	proc = subprocess.Popen(
		cmd, 
		stdin=subprocess.PIPE)
	try:
		proc.communicate(str(num) + '\n')
	except IOError:
		time.sleep(1)
		proc.communicate(str(num) + '\n')
	
	return proc.returncode - 1
	




